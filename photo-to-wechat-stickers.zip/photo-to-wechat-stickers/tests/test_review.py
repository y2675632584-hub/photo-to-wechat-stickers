"""Synthetic gate tests; passing fixtures are not production visual reviews."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from PIL import Image

spec = importlib.util.spec_from_file_location('review', Path(__file__).parents[1]/'scripts/review_stickers.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

class GateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name); self.root = self.base/'delivery'; self.root.mkdir()
        for f in r.FOLDERS: (self.root/f).mkdir()
        for n in ('cover','icon','banner'):
            Image.new('RGB',(50,50),'red').save(self.root/'配图'/f'{n}.png')
        a=Image.new('RGB',(240,240),'red'); b=Image.new('RGB',(240,240),'blue')
        self.gif=self.root/'动图'/'test.gif'
        a.save(self.gif,save_all=True,append_images=[b],duration=120,loop=0)
        a.save(self.root/'预览图'/'test.png')
        (self.root/'文案'/'copy.txt').write_text('synthetic fixture')
        self.report=self.base/'audit'/'review.json'; r.prepare(self.root,self.report)
    def approve_fixture(self):
        data=json.loads(self.report.read_text())
        for row in data['assets']:
            for check in row['checks'].values():
                check.update(status='pass',note='Synthetic test fixture only')
            if 'technical' in row:
                row['reviewed_frames']=list(range(1,row['technical']['frames']+1))
        self.report.write_text(json.dumps(data)); return data
    def test_pending_blocks(self):
        with self.assertRaises(ValueError): r.gate(self.root,self.report)
    def test_fail_blocks(self):
        d=self.approve_fixture(); d['assets'][0]['checks']['anatomy']['status']='fail'
        self.report.write_text(json.dumps(d))
        with self.assertRaises(ValueError): r.gate(self.root,self.report)
    def test_missing_frame_blocks(self):
        d=self.approve_fixture()
        next(x for x in d['assets'] if x['file'].endswith('.gif'))['reviewed_frames']=[1]
        self.report.write_text(json.dumps(d))
        with self.assertRaises(ValueError): r.gate(self.root,self.report)
    def test_changed_file_blocks(self):
        self.approve_fixture(); (self.root/'文案'/'copy.txt').write_text('changed')
        with self.assertRaises(ValueError): r.gate(self.root,self.report)
    def test_new_file_blocks(self):
        self.approve_fixture(); (self.root/'文案'/'extra.txt').write_text('new')
        with self.assertRaises(ValueError): r.gate(self.root,self.report)
    def test_static_gif_blocks(self):
        Image.new('RGB',(240,240),'red').save(self.gif)
        self.report.unlink(); r.prepare(self.root,self.report); self.approve_fixture()
        with self.assertRaises(ValueError): r.gate(self.root,self.report)
    def test_pack_verified(self):
        self.approve_fixture(); out=self.base/'result.zip'; r.pack(self.root,self.report,out)
        self.assertTrue(out.exists())
        with self.assertRaises(ValueError): r.pack(self.root,self.report,out)

if __name__ == '__main__': unittest.main()
