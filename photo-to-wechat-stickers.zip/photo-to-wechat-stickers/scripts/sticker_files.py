"""Local sticker conversion and inspection. No network or account access."""
import argparse
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageOps, ImageSequence


def inspect(path, args):
    with Image.open(path) as im:
        frames = getattr(im, 'n_frames', 1)
        result = {'file': str(path), 'format': im.format, 'size': list(im.size),
                  'bytes': path.stat().st_size, 'frames': frames,
                  'loop': im.info.get('loop'), 'errors': []}
        if im.size != (args.size, args.size):
            result['errors'].append('dimensions')
        if result['bytes'] > args.max_kb * 1000:
            result['errors'].append('file_size')
        if getattr(args, 'animated', False) and (im.format != 'GIF' or frames < 2):
            result['errors'].append('not_animated_gif')
        if getattr(args, 'loop', False) and im.info.get('loop') != 0:
            result['errors'].append('not_infinite_loop')
        # Inspect every decoded frame, not just the container header.
        duration = 0
        transparent = []
        unique = set()
        delays = []
        for frame in ImageSequence.Iterator(im):
            rgba = frame.convert('RGBA')
            transparent.append(rgba.getchannel('A').getextrema()[0] == 0)
            delay = frame.info.get('duration', 0)
            duration += delay
            delays.append(delay)
            unique.add(hashlib.sha256(rgba.tobytes()).hexdigest())
        result['duration_ms'] = duration
        result['unique_frames'] = len(unique)
        if getattr(args, 'animated', False):
            if len(unique) < 2:
                result['errors'].append('identical_frames')
            if any(d <= 0 for d in delays):
                result['errors'].append('zero_frame_duration')
        result['transparent_every_frame'] = all(transparent)
        if getattr(args, 'transparent', False) and not all(transparent):
            result['errors'].append('missing_transparency')
        return result


def export(args):
    src, dst = Path(args.source), Path(args.destination)
    thumb = Path(args.thumbnail) if args.thumbnail else None
    if dst.suffix.lower() != '.gif':
        raise ValueError('Destination must have .gif extension')
    if dst.exists() or (thumb and thumb.exists()):
        raise ValueError('Choose new output paths; existing files are preserved')
    if src.resolve() == dst.resolve() or (thumb and thumb.resolve() in {src.resolve(), dst.resolve()}):
        raise ValueError('Source, GIF and thumbnail must have distinct paths')
    frames, delays = [], []
    with Image.open(src) as im:
        if im.format != 'GIF' or getattr(im, 'n_frames', 1) < 2:
            raise ValueError('Input must be an existing animated GIF')
        for frame in ImageSequence.Iterator(im):
            if len(frames) >= 500:
                raise ValueError('Input exceeds 500 frames; use a shorter animation')
            canvas = Image.new('RGBA', (args.size, args.size))
            fitted = ImageOps.contain(frame.convert('RGBA'), canvas.size, Image.Resampling.LANCZOS)
            canvas.alpha_composite(fitted, ((args.size-fitted.width)//2, (args.size-fitted.height)//2))
            frames.append(canvas)
            delays.append(max(20, int(frame.info.get('duration', 100))))
    indexed = []
    for frame in frames:
        q = frame.quantize(colors=255, method=Image.Quantize.FASTOCTREE)
        q.paste(255, mask=frame.getchannel('A').point(lambda a: 255 if a < 128 else 0))
        q.info['transparency'] = 255
        indexed.append(q)
    dst.parent.mkdir(parents=True, exist_ok=True)
    indexed[0].save(dst, save_all=True, append_images=indexed[1:], duration=delays,
                    loop=0, disposal=2, transparency=255, optimize=False)
    if thumb:
        thumb.parent.mkdir(parents=True, exist_ok=True)
        frames[len(frames)//2].resize((120, 120), Image.Resampling.LANCZOS).save(thumb, format='PNG', optimize=True)
    args.animated, args.loop = True, True
    return [inspect(dst, args)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('export', 'check'):
        p = commands.add_parser(name)
        p.add_argument('--size', type=int, default=240)
        p.add_argument('--max-kb', type=int, default=500)
        p.add_argument('--report', type=Path)
        if name == 'export':
            p.add_argument('source')
            p.add_argument('destination')
            p.add_argument('--thumbnail')
        else:
            p.add_argument('files', nargs='+', type=Path)
            p.add_argument('--animated', action='store_true')
            p.add_argument('--loop', action='store_true')
            p.add_argument('--transparent', action='store_true')
    args = parser.parse_args()
    if not 1 <= args.size <= 2048 or args.max_kb < 1:
        parser.error('size must be 1..2048 and max-kb must be positive')
    try:
        results = export(args) if args.command == 'export' else [inspect(p, args) for p in args.files]
    except (OSError, ValueError) as exc:
        parser.exit(2, str(exc) + '\n')
    output = json.dumps(results, ensure_ascii=False, indent=2)
    print(output)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding='utf-8')
    return 1 if any(r['errors'] for r in results) else 0


if __name__ == '__main__':
    raise SystemExit(main())
